      // Ofuscación del número de teléfono
      const phone = "652" + "681" + "155";
      document.getElementById("phone").innerHTML =
        "Teléfono: <a href='tel:" + phone + "' class='green'>" + phone + "</a>";

      const skills = [
        "Inicializanbdo habilidades técnicas",
        "Cargando experiencia",
        "Arrancando más de 10 años en php",
        "Conectando con bases de datos desde 2007",
        "Lanzando librerias de JavaScript",
        "Renderizando estrucutra HTML",
        "Aplicando estilos CSS",
        "Posibilidada de compilar a SWIFT",
        "Cargando videojuegos con UNITY",
        "Activando páginas web en Wordpress",
        "Integrando tiendas virtuales con WooCommerce",
        "Desarrollo de apps completas",
        "Carga completada. Developer fully operational",
      ];

      const bootLog = document.getElementById("boot-log");
      const loadingBar = document.getElementById("loading-bar");
      let skillIndex = 0;

      function updateLoadingBar(progress) {
        const total = 20;
        const filled = Math.round((progress / skills.length) * total);
        const bar = "[" + ".".repeat(filled) + " ".repeat(total - filled) + "]";
        loadingBar.textContent = bar;
      }

      function loadSkillWithDots(skill, callback) {
        let dots = 0;
        const maxDots = 20;
        const interval = setInterval(() => {
          const line = skill + ".".repeat(dots);
          const lines = bootLog.innerHTML.split("\n");
          lines[lines.length - 1] = line;
          bootLog.innerHTML = lines.join("\n");
          dots++;
          if (dots > maxDots) {
            clearInterval(interval);
            // Añadir COMPLETE al final de la línea
            const completeLine = skill + ".".repeat(maxDots) + " <span class='yellow'>COMPLETADO</span>";
            const lines = bootLog.innerHTML.split("\n");
            lines[lines.length - 1] = completeLine;
            bootLog.innerHTML = lines.join("\n");
            callback();
          }
        }, 80);
      }

      function loadNextSkill() {
        if (skillIndex < skills.length) {
          bootLog.innerHTML += "\n"; // Añade una nueva línea vacía para empezar
          loadSkillWithDots(skills[skillIndex], () => {
            updateLoadingBar(skillIndex + 1);
            skillIndex++;
            setTimeout(loadNextSkill, 300);
          });
        }
      }

      window.onload = loadNextSkill;

      const dialogues = [
        {
          speaker: "Entrevistador",
          text: "Hola Jose Ángel, gracias por venir. ¿Cómo te encuentras hoy?",
        },
        {
          speaker: "Jose Ángel",
          text: "Muy bien, gracias. Con muchas ganas de esta entrevista.",
        },
        {
          speaker: "Entrevistador",
          text: "Nos alegra. Queremos conocerte más allá del código. ¿Cómo describirías tu forma de trabajar en equipo?",
        },
        {
          speaker: "Jose Ángel",
          text: "Me considero una persona colaborativa. Me gusta escuchar, aportar ideas y adaptarme al estilo de trabajo del equipo.",
        },
        {
          speaker: "Entrevistador",
          text: "¿Cómo manejas los desacuerdos o conflictos en un proyecto?",
        },
        {
          speaker: "Jose Ángel",
          text: "Intento entender el punto de vista del otro, buscar soluciones objetivas y mantener siempre una comunicación respetuosa.",
        },
        {
          speaker: "Entrevistador",
          text: "¿Qué valoras más en un entorno de trabajo?",
        },
        {
          speaker: "Jose Ángel",
          text: "La confianza, la claridad en los objetivos y un ambiente donde se pueda aprender y crecer sin miedo a equivocarse.",
        },
        {
          speaker: "Entrevistador",
          text: "¿Cómo gestionas el estrés o los plazos ajustados?",
        },
        {
          speaker: "Jose Ángel",
          text: "Organizo tareas por prioridad, mantengo la calma y si es necesario, pido ayuda o renegocio tiempos con transparencia.",
        },
        {
          speaker: "Entrevistador",
          text: "¿Qué haces cuando te enfrentas a un problema técnico que no sabes resolver?",
        },
        {
          speaker: "Jose Ángel",
          text: "Investigo, pruebo soluciones, consulto documentación y si hace falta, pido consejo a compañeros. Me gusta aprender de cada reto.",
        },
        {
          speaker: "Entrevistador",
          text: "¿Qué te motiva como desarrollador?",
        },
        {
          speaker: "Jose Ángel",
          text: "Ver cómo una idea se convierte en una solución útil. Y saber que lo que hago tiene impacto real en usuarios o empresas.",
        },
        {
          speaker: "Entrevistador",
          text: "¿Tienes alguna experiencia donde tu actitud haya marcado la diferencia?",
        },
        {
          speaker: "Jose Ángel",
          text: "Sí, en un proyecto con mucho retraso, propuse reorganizar tareas y mejorar la comunicación. Logramos entregarlo a tiempo y con buena calidad.",
        },
        {
          speaker: "Entrevistador",
          text: "¿Qué esperas de nosotros como empresa?",
        },
        {
          speaker: "Jose Ángel",
          text: "Un entorno donde pueda seguir creciendo, aportar valor y sentirme parte de un equipo con visión y propósito.",
        },
        {
          speaker: "Entrevistador",
          text: "Gracias Jose Ángel. Ha sido un placer conocerte.",
        },
        {
          speaker: "Jose Ángel",
          text: "Gracias a ustedes. Espero poder formar parte del equipo.",
        },
      ];

      let currentIndex = -1;

      let avatar = document.querySelector(".avatar");
      let cajaDialogo = document.getElementById("caja-dialogo");
      let speaker = document.getElementById("speaker");
      let dialogue = document.getElementById("dialogue");
      let visualNovel = document.querySelector(".visual-novel");

      function nextDialogue() {
        if (currentIndex === -1) {
          avatar.style.display = "block";
          cajaDialogo.style.display = "block";
          visualNovel.style.backgroundImage = "url('imagenes/oficina1.jpeg')";
        }

        currentIndex++;
        if (currentIndex < dialogues.length) {
          if (dialogues[currentIndex].speaker === "Jose Ángel") {
            avatar.style.backgroundImage = "url('imagenes/avatar.png')";
            avatar.style.float = "left";
          } else {
            avatar.style.backgroundImage = "url('imagenes/entrevistador.png')";
            avatar.style.float = "right";
          }
          speaker.innerText = dialogues[currentIndex].speaker;
          dialogue.innerText = dialogues[currentIndex].text;
        }
      }